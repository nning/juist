---------------- MODULE trace ----------------
\* <Action line 24, col 22 to line 24, col 33 of module PairKeyTrace>
STATE_1 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 0,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 0 ]
/\ net = {}
/\ took = [from |-> "none"]
/\ ids = 2
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoAdvance line 14, col 14 to line 14, col 37 of module PairKeyTrace>
STATE_2 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = {}
/\ took = [from |-> "none"]
/\ ids = 3
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoSendL line 12, col 12 to line 12, col 33 of module PairKeyTrace>
STATE_3 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 3
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoSendF line 13, col 12 to line 13, col 33 of module PairKeyTrace>
STATE_4 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 3
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeF line 11, col 12 to line 11, col 47 of module PairKeyTrace>
STATE_5 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [ from |-> "L",
  epoch |-> 1,
  store |-> 1,
  to |-> 2,
  gen |-> 1,
  ct |-> 3,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoSendL line 12, col 12 to line 12, col 33 of module PairKeyTrace>
STATE_6 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeL line 10, col 12 to line 10, col 47 of module PairKeyTrace>
STATE_7 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [ from |-> "F",
  epoch |-> 0,
  store |-> 2,
  to |-> 1,
  gen |-> 0,
  ct |-> 0,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeF line 11, col 12 to line 11, col 47 of module PairKeyTrace>
STATE_8 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [ from |-> "L",
  epoch |-> 1,
  store |-> 1,
  to |-> 2,
  gen |-> 1,
  ct |-> 3,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoSendL line 12, col 12 to line 12, col 33 of module PairKeyTrace>
STATE_9 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeF line 11, col 12 to line 11, col 47 of module PairKeyTrace>
STATE_10 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [ from |-> "L",
  epoch |-> 1,
  store |-> 1,
  to |-> 2,
  gen |-> 1,
  ct |-> 3,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoSendL line 12, col 12 to line 12, col 33 of module PairKeyTrace>
STATE_11 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoSendF line 13, col 12 to line 13, col 33 of module PairKeyTrace>
STATE_12 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeL line 10, col 12 to line 10, col 47 of module PairKeyTrace>
STATE_13 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [ from |-> "F",
  epoch |-> 1,
  store |-> 2,
  to |-> 1,
  gen |-> 1,
  ct |-> 4,
  check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoSendF line 13, col 12 to line 13, col 33 of module PairKeyTrace>
STATE_14 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoProbe line 15, col 12 to line 15, col 33 of module PairKeyTrace>
STATE_15 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeF line 11, col 12 to line 11, col 47 of module PairKeyTrace>
STATE_16 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [ from |-> "L",
  epoch |-> 1,
  store |-> 1,
  to |-> 2,
  gen |-> 1,
  ct |-> 3,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeL line 10, col 12 to line 10, col 47 of module PairKeyTrace>
STATE_17 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [ from |-> "F",
  epoch |-> 0,
  store |-> 2,
  to |-> 1,
  gen |-> 0,
  ct |-> 0,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeF line 11, col 12 to line 11, col 47 of module PairKeyTrace>
STATE_18 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [ from |-> "L",
  epoch |-> 1,
  store |-> 1,
  to |-> 2,
  gen |-> 1,
  ct |-> 3,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeL line 10, col 12 to line 10, col 47 of module PairKeyTrace>
STATE_19 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [ from |-> "F",
  epoch |-> 1,
  store |-> 2,
  to |-> 1,
  gen |-> 1,
  ct |-> 4,
  check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoProbe line 15, col 12 to line 15, col 33 of module PairKeyTrace>
STATE_20 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoProbe line 15, col 12 to line 15, col 33 of module PairKeyTrace>
STATE_21 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoSendL line 12, col 12 to line 12, col 33 of module PairKeyTrace>
STATE_22 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeL line 10, col 12 to line 10, col 47 of module PairKeyTrace>
STATE_23 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [ from |-> "F",
  epoch |-> 0,
  store |-> 2,
  to |-> 1,
  gen |-> 0,
  ct |-> 0,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoSendL line 12, col 12 to line 12, col 33 of module PairKeyTrace>
STATE_24 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeL line 10, col 12 to line 10, col 47 of module PairKeyTrace>
STATE_25 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [ from |-> "F",
  epoch |-> 0,
  store |-> 2,
  to |-> 1,
  gen |-> 0,
  ct |-> 0,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoProbe line 15, col 12 to line 15, col 33 of module PairKeyTrace>
STATE_26 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeL line 10, col 12 to line 10, col 47 of module PairKeyTrace>
STATE_27 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [ from |-> "F",
  epoch |-> 0,
  store |-> 2,
  to |-> 1,
  gen |-> 0,
  ct |-> 0,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoProbe line 15, col 12 to line 15, col 33 of module PairKeyTrace>
STATE_28 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeL line 10, col 12 to line 10, col 47 of module PairKeyTrace>
STATE_29 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [ from |-> "F",
  epoch |-> 0,
  store |-> 2,
  to |-> 1,
  gen |-> 0,
  ct |-> 0,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoSendF line 13, col 12 to line 13, col 33 of module PairKeyTrace>
STATE_30 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeL line 10, col 12 to line 10, col 47 of module PairKeyTrace>
STATE_31 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [ from |-> "F",
  epoch |-> 0,
  store |-> 2,
  to |-> 1,
  gen |-> 0,
  ct |-> 0,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeF line 11, col 12 to line 11, col 47 of module PairKeyTrace>
STATE_32 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> TRUE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [ from |-> "L",
  epoch |-> 1,
  store |-> 1,
  to |-> 2,
  gen |-> 1,
  ct |-> 0,
  check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  use |-> 1 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoProbe line 15, col 12 to line 15, col 33 of module PairKeyTrace>
STATE_33 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeF line 11, col 12 to line 11, col 47 of module PairKeyTrace>
STATE_34 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [ from |-> "L",
  epoch |-> 1,
  store |-> 1,
  to |-> 2,
  gen |-> 1,
  ct |-> 0,
  check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  use |-> 1 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeL line 10, col 12 to line 10, col 47 of module PairKeyTrace>
STATE_35 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 0,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 1 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 1,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 1,
    store |-> 2,
    to |-> 1,
    gen |-> 1,
    ct |-> 4,
    check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
    use |-> 0 ] }
/\ took = [ from |-> "F",
  epoch |-> 1,
  store |-> 2,
  to |-> 1,
  gen |-> 1,
  ct |-> 4,
  check |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


=================================================
