---------------- MODULE trace ----------------
\* <TraceInit line 10, col 3 to line 13, col 63 of module Trace>
STATE_1 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = <<>>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_2 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_3 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_4 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<3>>,
     hrank |-> 1,
     srank |-> 1 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_5 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 1,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 1>>,
     hrank |-> 1,
     srank |-> 2 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_6 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 1,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 1>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k2, k3},
     parent |-> 0,
     after |->
         [ admins |-> {k1, k2, k3},
           quorum |-> 2,
           nodes |-> {n1, n2},
           epoch |-> 1 ],
     key |-> <<5>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_7 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 4} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 1,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 1>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k2, k3},
     parent |-> 0,
     after |->
         [ admins |-> {k1, k2, k3},
           quorum |-> 2,
           nodes |-> {n1, n2},
           epoch |-> 1 ],
     key |-> <<5>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_8 == 
/\ floor = (v1 :> 0 @@ v2 :> 1)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 4} @@ v2 :> {0, 5})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 1,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 1>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k2, k3},
     parent |-> 0,
     after |->
         [ admins |-> {k1, k2, k3},
           quorum |-> 2,
           nodes |-> {n1, n2},
           epoch |-> 1 ],
     key |-> <<5>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 5>>,
        onChain |-> {0, 5},
        head |-> 5,
        state |->
            [ admins |-> {k1, k2, k3},
              quorum |-> 2,
              nodes |-> {n1, n2},
              epoch |-> 1 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_9 == 
/\ floor = (v1 :> 0 @@ v2 :> 1)
/\ rollback = (v1 :> FALSE @@ v2 :> TRUE)
/\ store = (v1 :> {0, 4} @@ v2 :> {0, 2, 5})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 1,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 1>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k2, k3},
     parent |-> 0,
     after |->
         [ admins |-> {k1, k2, k3},
           quorum |-> 2,
           nodes |-> {n1, n2},
           epoch |-> 1 ],
     key |-> <<5>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 2>>,
        onChain |-> {0, 2},
        head |-> 2,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_10 == 
/\ floor = (v1 :> 0 @@ v2 :> 1)
/\ rollback = (v1 :> FALSE @@ v2 :> TRUE)
/\ store = (v1 :> {0, 4} @@ v2 :> {0, 2, 4, 5})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 1,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 1>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k2, k3},
     parent |-> 0,
     after |->
         [ admins |-> {k1, k2, k3},
           quorum |-> 2,
           nodes |-> {n1, n2},
           epoch |-> 1 ],
     key |-> <<5>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_11 == 
/\ floor = (v1 :> 0 @@ v2 :> 1)
/\ rollback = (v1 :> FALSE @@ v2 :> TRUE)
/\ store = (v1 :> {0, 4, 5} @@ v2 :> {0, 2, 4, 5})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 1,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 1>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k2, k3},
     parent |-> 0,
     after |->
         [ admins |-> {k1, k2, k3},
           quorum |-> 2,
           nodes |-> {n1, n2},
           epoch |-> 1 ],
     key |-> <<5>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_12 == 
/\ floor = (v1 :> 0 @@ v2 :> 1)
/\ rollback = (v1 :> FALSE @@ v2 :> TRUE)
/\ store = (v1 :> {0, 4, 5} @@ v2 :> {0, 1, 2, 4, 5})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 1,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 1>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k2, k3},
     parent |-> 0,
     after |->
         [ admins |-> {k1, k2, k3},
           quorum |-> 2,
           nodes |-> {n1, n2},
           epoch |-> 1 ],
     key |-> <<5>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_13 == 
/\ floor = (v1 :> 1 @@ v2 :> 1)
/\ rollback = (v1 :> FALSE @@ v2 :> TRUE)
/\ store = (v1 :> {0, 3, 4, 5} @@ v2 :> {0, 1, 2, 4, 5})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 1,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 1>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k2, k3},
     parent |-> 0,
     after |->
         [ admins |-> {k1, k2, k3},
           quorum |-> 2,
           nodes |-> {n1, n2},
           epoch |-> 1 ],
     key |-> <<5>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 3>>,
        onChain |-> {0, 3},
        head |-> 3,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 1 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_14 == 
/\ floor = (v1 :> 1 @@ v2 :> 1)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 3, 4, 5} @@ v2 :> {0, 1, 2, 3, 4, 5})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 1,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 1>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k2, k3},
     parent |-> 0,
     after |->
         [ admins |-> {k1, k2, k3},
           quorum |-> 2,
           nodes |-> {n1, n2},
           epoch |-> 1 ],
     key |-> <<5>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 3>>,
        onChain |-> {0, 3},
        head |-> 3,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 1 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 3>>,
        onChain |-> {0, 3},
        head |-> 3,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 1 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_15 == 
/\ floor = (v1 :> 1 @@ v2 :> 1)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 2, 3, 4, 5} @@ v2 :> {0, 1, 2, 3, 4, 5})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 1,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 1>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k2, k3},
     parent |-> 0,
     after |->
         [ admins |-> {k1, k2, k3},
           quorum |-> 2,
           nodes |-> {n1, n2},
           epoch |-> 1 ],
     key |-> <<5>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 3>>,
        onChain |-> {0, 3},
        head |-> 3,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 1 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 3>>,
        onChain |-> {0, 3},
        head |-> 3,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 1 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_16 == 
/\ floor = (v1 :> 1 @@ v2 :> 1)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 1, 2, 3, 4, 5} @@ v2 :> {0, 1, 2, 3, 4, 5})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 5 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 1,
     signers |-> {k1, k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 1>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k2, k3},
     parent |-> 0,
     after |->
         [ admins |-> {k1, k2, k3},
           quorum |-> 2,
           nodes |-> {n1, n2},
           epoch |-> 1 ],
     key |-> <<5>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 3>>,
        onChain |-> {0, 3},
        head |-> 3,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 1 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 3>>,
        onChain |-> {0, 3},
        head |-> 3,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 1 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


=================================================
