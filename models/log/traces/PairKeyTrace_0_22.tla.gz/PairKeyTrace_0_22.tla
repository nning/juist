---------------- MODULE trace ----------------
\* <Action line 24, col 22 to line 24, col 33 of module PairKeyTrace>
STATE_1 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 0,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 0 ]
/\ net = {}
/\ took = [from |-> "none"]
/\ ids = 2
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoAdvance line 14, col 14 to line 14, col 37 of module PairKeyTrace>
STATE_2 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = {}
/\ took = [from |-> "none"]
/\ ids = 3
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoSendL line 12, col 12 to line 12, col 33 of module PairKeyTrace>
STATE_3 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 3
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeF line 11, col 12 to line 11, col 47 of module PairKeyTrace>
STATE_4 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [ from |-> "L",
  epoch |-> 1,
  store |-> 1,
  to |-> 2,
  gen |-> 1,
  ct |-> 3,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoKeepF line 21, col 12 to line 21, col 33 of module PairKeyTrace>
STATE_5 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 1,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 4
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]


\* <DoResetL line 18, col 13 to line 18, col 35 of module PairKeyTrace>
STATE_6 == 
/\ epoch = 1
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 5,
  peer |-> 2,
  last |-> 0,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 0 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 5
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]


\* <DoBump line 16, col 11 to line 16, col 31 of module PairKeyTrace>
STATE_7 == 
/\ epoch = 2
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 5,
  peer |-> 2,
  last |-> 0,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 0 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 5
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]


\* <DoTakeF line 11, col 12 to line 11, col 47 of module PairKeyTrace>
STATE_8 == 
/\ epoch = 2
/\ F = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]
/\ L = [ store |-> 5,
  peer |-> 2,
  last |-> 0,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 0 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [ from |-> "L",
  epoch |-> 1,
  store |-> 1,
  to |-> 2,
  gen |-> 1,
  ct |-> 3,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 5
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]


\* <DoAnnounceToF line 20, col 18 to line 20, col 45 of module PairKeyTrace>
STATE_9 == 
/\ epoch = 2
/\ F = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 5,
  peer |-> 2,
  last |-> 0,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 0 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 5
/\ keptF = [ store |-> 2,
  peer |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 1, e |-> 1, l |-> 3, f |-> 4] ]


\* <DoKeepF line 21, col 12 to line 21, col 33 of module PairKeyTrace>
STATE_10 == 
/\ epoch = 2
/\ F = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 5,
  peer |-> 2,
  last |-> 0,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 0 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 5
/\ keptF = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoSendF line 13, col 12 to line 13, col 33 of module PairKeyTrace>
STATE_11 == 
/\ epoch = 2
/\ F = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 5,
  peer |-> 2,
  last |-> 0,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 0 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 5,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 5
/\ keptF = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeL line 10, col 12 to line 10, col 47 of module PairKeyTrace>
STATE_12 == 
/\ epoch = 2
/\ F = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 5,
  peer |-> 2,
  last |-> 0,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 0 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 5,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [ from |-> "F",
  epoch |-> 0,
  store |-> 2,
  to |-> 5,
  gen |-> 0,
  ct |-> 0,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 5
/\ keptF = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoAdvance line 14, col 14 to line 14, col 37 of module PairKeyTrace>
STATE_13 == 
/\ epoch = 2
/\ F = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 5,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 2, l |-> 6, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 5,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 6
/\ keptF = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoTakeL line 10, col 12 to line 10, col 47 of module PairKeyTrace>
STATE_14 == 
/\ epoch = 2
/\ F = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 5,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 2, l |-> 6, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 5,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [ from |-> "F",
  epoch |-> 0,
  store |-> 2,
  to |-> 5,
  gen |-> 0,
  ct |-> 0,
  check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  use |-> 0 ]
/\ ids = 6
/\ keptF = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoRestoreF line 22, col 15 to line 22, col 39 of module PairKeyTrace>
STATE_15 == 
/\ epoch = 2
/\ F = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 5,
  peer |-> 2,
  last |-> 1,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 1, e |-> 2, l |-> 6, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 1 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 5,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 6
/\ keptF = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoResetL line 18, col 13 to line 18, col 35 of module PairKeyTrace>
STATE_16 == 
/\ epoch = 2
/\ F = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 7,
  peer |-> 2,
  last |-> 0,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 0 ]
/\ net = { [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 5,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 7
/\ keptF = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoSendL line 12, col 12 to line 12, col 33 of module PairKeyTrace>
STATE_17 == 
/\ epoch = 2
/\ F = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 7,
  peer |-> 2,
  last |-> 0,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 0 ]
/\ net = { [ from |-> "L",
    epoch |-> 0,
    store |-> 7,
    to |-> 2,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 5,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 7
/\ keptF = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoAnnounceToF line 20, col 18 to line 20, col 45 of module PairKeyTrace>
STATE_18 == 
/\ epoch = 2
/\ F = [ store |-> 2,
  peer |-> 7,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 7,
  peer |-> 2,
  last |-> 0,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 0 ]
/\ net = { [ from |-> "L",
    epoch |-> 0,
    store |-> 7,
    to |-> 2,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 5,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 7
/\ keptF = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


\* <DoRestoreF line 22, col 15 to line 22, col 39 of module PairKeyTrace>
STATE_19 == 
/\ epoch = 2
/\ F = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]
/\ L = [ store |-> 7,
  peer |-> 2,
  last |-> 0,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  next |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  pend |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  flip |-> FALSE,
  redo |-> FALSE,
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  slast |-> 0 ]
/\ net = { [ from |-> "L",
    epoch |-> 0,
    store |-> 7,
    to |-> 2,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "L",
    epoch |-> 1,
    store |-> 1,
    to |-> 2,
    gen |-> 1,
    ct |-> 3,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ],
  [ from |-> "F",
    epoch |-> 0,
    store |-> 2,
    to |-> 5,
    gen |-> 0,
    ct |-> 0,
    check |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
    use |-> 0 ] }
/\ took = [from |-> "none"]
/\ ids = 7
/\ keptF = [ store |-> 2,
  peer |-> 5,
  cur |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  prev |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0],
  offered |-> [n |-> 0, e |-> 0, l |-> 0, f |-> 0] ]


=================================================
