---------------- MODULE trace ----------------
\* <TraceInit line 10, col 3 to line 13, col 63 of module Trace>
STATE_1 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = <<>>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_2 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 3, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 3,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 3>>,
     hrank |-> 1,
     srank |-> 1 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_3 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 3, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 3,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1},
     parent |-> 0,
     key |-> <<2>>,
     hrank |-> 1,
     srank |-> 3 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_4 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 3, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 3,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1},
     parent |-> 0,
     key |-> <<2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k3},
     parent |-> 1,
     key |-> <<1, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 2 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_5 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 3, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 3,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1},
     parent |-> 0,
     key |-> <<2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k3},
     parent |-> 1,
     key |-> <<1, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "RemoveAdmin",
     subj |-> k3,
     q |-> 0,
     signers |-> {k2},
     parent |-> 0,
     after |-> [admins |-> {k1, k2}, quorum |-> 1, nodes |-> {n1}, epoch |-> 0],
     key |-> <<0, "RemoveAdmin", k3, 0>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_6 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0, 1})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 3, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 3,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1},
     parent |-> 0,
     key |-> <<2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k3},
     parent |-> 1,
     key |-> <<1, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "RemoveAdmin",
     subj |-> k3,
     q |-> 0,
     signers |-> {k2},
     parent |-> 0,
     after |-> [admins |-> {k1, k2}, quorum |-> 1, nodes |-> {n1}, epoch |-> 0],
     key |-> <<0, "RemoveAdmin", k3, 0>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 1>>,
        onChain |-> {0, 1},
        head |-> 1,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 3,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_7 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0, 1, 2})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 3, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 3,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1},
     parent |-> 0,
     key |-> <<2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k3},
     parent |-> 1,
     key |-> <<1, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "RemoveAdmin",
     subj |-> k3,
     q |-> 0,
     signers |-> {k2},
     parent |-> 0,
     after |-> [admins |-> {k1, k2}, quorum |-> 1, nodes |-> {n1}, epoch |-> 0],
     key |-> <<0, "RemoveAdmin", k3, 0>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 1>>,
        onChain |-> {0, 1},
        head |-> 1,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 3,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_8 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 4} @@ v2 :> {0, 1, 2})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 3, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 3,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1},
     parent |-> 0,
     key |-> <<2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k3},
     parent |-> 1,
     key |-> <<1, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "RemoveAdmin",
     subj |-> k3,
     q |-> 0,
     signers |-> {k2},
     parent |-> 0,
     after |-> [admins |-> {k1, k2}, quorum |-> 1, nodes |-> {n1}, epoch |-> 0],
     key |-> <<0, "RemoveAdmin", k3, 0>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [admins |-> {k1, k2}, quorum |-> 1, nodes |-> {n1}, epoch |-> 0],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 1>>,
        onChain |-> {0, 1},
        head |-> 1,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 3,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_9 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 2, 4} @@ v2 :> {0, 1, 2})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 3, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 3,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1},
     parent |-> 0,
     key |-> <<2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k3},
     parent |-> 1,
     key |-> <<1, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "RemoveAdmin",
     subj |-> k3,
     q |-> 0,
     signers |-> {k2},
     parent |-> 0,
     after |-> [admins |-> {k1, k2}, quorum |-> 1, nodes |-> {n1}, epoch |-> 0],
     key |-> <<0, "RemoveAdmin", k3, 0>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [admins |-> {k1, k2}, quorum |-> 1, nodes |-> {n1}, epoch |-> 0],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 1>>,
        onChain |-> {0, 1},
        head |-> 1,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 3,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_10 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 2, 4} @@ v2 :> {0, 1, 2, 4})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 3, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 3,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1},
     parent |-> 0,
     key |-> <<2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k3},
     parent |-> 1,
     key |-> <<1, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "RemoveAdmin",
     subj |-> k3,
     q |-> 0,
     signers |-> {k2},
     parent |-> 0,
     after |-> [admins |-> {k1, k2}, quorum |-> 1, nodes |-> {n1}, epoch |-> 0],
     key |-> <<0, "RemoveAdmin", k3, 0>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [admins |-> {k1, k2}, quorum |-> 1, nodes |-> {n1}, epoch |-> 0],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [admins |-> {k1, k2}, quorum |-> 1, nodes |-> {n1}, epoch |-> 0],
        alarm |-> TRUE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


\* <Action line 15, col 30 to line 15, col 52 of module Trace>
STATE_11 == 
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 1, 2, 4} @@ v2 :> {0, 1, 2, 4})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 3, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 3,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 3>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
     kind |-> "EpochBump",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1},
     parent |-> 0,
     key |-> <<2>>,
     hrank |-> 1,
     srank |-> 3 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k3},
     parent |-> 1,
     key |-> <<1, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ kind |-> "RemoveAdmin",
     subj |-> k3,
     q |-> 0,
     signers |-> {k2},
     parent |-> 0,
     after |-> [admins |-> {k1, k2}, quorum |-> 1, nodes |-> {n1}, epoch |-> 0],
     key |-> <<0, "RemoveAdmin", k3, 0>>,
     hrank |-> 1,
     srank |-> 4 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [admins |-> {k1, k2}, quorum |-> 1, nodes |-> {n1}, epoch |-> 0],
        alarm |-> TRUE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 4>>,
        onChain |-> {0, 4},
        head |-> 4,
        state |->
            [admins |-> {k1, k2}, quorum |-> 1, nodes |-> {n1}, epoch |-> 0],
        alarm |-> TRUE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>


=================================================
