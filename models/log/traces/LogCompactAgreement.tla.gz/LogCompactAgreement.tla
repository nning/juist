---------------- MODULE trace ----------------
STATE_1 ==
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = <<>>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

STATE_2 ==
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [ nodes |-> {n1, n2},
           admins |-> {k1, k2, k3},
           quorum |-> 2,
           epoch |-> 1 ],
     kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<1>>,
     hrank |-> 1,
     srank |-> 1 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

STATE_3 ==
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [ nodes |-> {n1, n2},
           admins |-> {k1, k2, k3},
           quorum |-> 2,
           epoch |-> 1 ],
     kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<1>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 2 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

STATE_4 ==
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 2} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [ nodes |-> {n1, n2},
           admins |-> {k1, k2, k3},
           quorum |-> 2,
           epoch |-> 1 ],
     kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<1>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 2 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 2>>,
        onChain |-> {0, 2},
        head |-> 2,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

STATE_5 ==
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 2} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [ nodes |-> {n1, n2},
           admins |-> {k1, k2, k3},
           quorum |-> 2,
           epoch |-> 1 ],
     kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<1>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 2,
     key |-> <<2, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 3 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 2>>,
        onChain |-> {0, 2},
        head |-> 2,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

STATE_6 ==
/\ floor = (v1 :> 1 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 1, 2} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [ nodes |-> {n1, n2},
           admins |-> {k1, k2, k3},
           quorum |-> 2,
           epoch |-> 1 ],
     kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<1>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 2,
     key |-> <<2, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 3 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 1>>,
        onChain |-> {0, 1},
        head |-> 1,
        state |->
            [ nodes |-> {n1, n2},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 1 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

STATE_7 ==
/\ floor = (v1 :> 1 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 1, 2} @@ v2 :> {0, 2})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [ nodes |-> {n1, n2},
           admins |-> {k1, k2, k3},
           quorum |-> 2,
           epoch |-> 1 ],
     kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<1>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 2,
     key |-> <<2, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 3 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 1>>,
        onChain |-> {0, 1},
        head |-> 1,
        state |->
            [ nodes |-> {n1, n2},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 1 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 2>>,
        onChain |-> {0, 2},
        head |-> 2,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

STATE_8 ==
/\ floor = (v1 :> 1 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 1, 2} @@ v2 :> {0, 2, 3})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [ nodes |-> {n1, n2},
           admins |-> {k1, k2, k3},
           quorum |-> 2,
           epoch |-> 1 ],
     kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<1>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 2,
     key |-> <<2, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 3 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 1>>,
        onChain |-> {0, 1},
        head |-> 1,
        state |->
            [ nodes |-> {n1, n2},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 1 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 2, 3>>,
        onChain |-> {0, 2, 3},
        head |-> 3,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

STATE_9 ==
/\ floor = (v1 :> 1 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 1, 2, 3} @@ v2 :> {0, 2, 3})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [ nodes |-> {n1, n2},
           admins |-> {k1, k2, k3},
           quorum |-> 2,
           epoch |-> 1 ],
     kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<1>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 2,
     key |-> <<2, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 3 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 1>>,
        onChain |-> {0, 1},
        head |-> 1,
        state |->
            [ nodes |-> {n1, n2},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 1 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0, 2, 3>>,
        onChain |-> {0, 2, 3},
        head |-> 3,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

STATE_10 ==
/\ floor = (v1 :> 1 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 1, 2, 3} @@ v2 :> {2, 3})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 2,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [ nodes |-> {n1, n2},
           admins |-> {k1, k2, k3},
           quorum |-> 2,
           epoch |-> 1 ],
     kind |-> "AddNode",
     subj |-> n2,
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<1>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 0,
     key |-> <<0, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 2 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "Checkpoint",
     subj |-> "-",
     q |-> 0,
     signers |-> {k1, k2},
     parent |-> 2,
     key |-> <<2, "Checkpoint", "-", 0>>,
     hrank |-> 1,
     srank |-> 3 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 1>>,
        onChain |-> {0, 1},
        head |-> 1,
        state |->
            [ nodes |-> {n1, n2},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 1 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<2, 3>>,
        onChain |-> {2, 3},
        head |-> 3,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 2,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 2)
/\ owed = <<>>

