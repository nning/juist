---------------- MODULE trace ----------------
STATE_1 ==
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = <<>>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

STATE_2 ==
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
     kind |-> "RemoveNode",
     subj |-> n1,
     q |-> 0,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<1>>,
     hrank |-> 1,
     srank |-> 1 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

STATE_3 ==
/\ floor = (v1 :> 0 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
     kind |-> "RemoveNode",
     subj |-> n1,
     q |-> 0,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<1>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 2 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

STATE_4 ==
/\ floor = (v1 :> 1 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 1} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
     kind |-> "RemoveNode",
     subj |-> n1,
     q |-> 0,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<1>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 2 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 1>>,
        onChain |-> {0, 1},
        head |-> 1,
        state |->
            [nodes |-> {}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
        alarm |-> FALSE,
        unrevoked |-> {} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

STATE_5 ==
/\ floor = (v1 :> 1 @@ v2 :> 0)
/\ rollback = (v1 :> FALSE @@ v2 :> FALSE)
/\ store = (v1 :> {0, 1, 2} @@ v2 :> {0})
/\ setup = [ keys |-> {k1, k2, k3},
  nodes |-> {n1, n2},
  validators |-> {v1, v2},
  admins |-> {k1, k2, k3},
  quorum |-> 1,
  members |-> {n1},
  paired |-> {},
  pairNeeded |-> 1 ]
/\ rec = << [ after |->
         [nodes |-> {}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
     kind |-> "RemoveNode",
     subj |-> n1,
     q |-> 0,
     signers |-> {k3},
     parent |-> 0,
     key |-> <<1>>,
     hrank |-> 1,
     srank |-> 1 ],
   [ after |->
         [nodes |-> {n1}, admins |-> {k1, k2, k3}, quorum |-> 2, epoch |-> 0],
     kind |-> "SetQuorum",
     subj |-> "-",
     q |-> 2,
     signers |-> {k1},
     parent |-> 0,
     key |-> <<0, "SetQuorum", "-", 2>>,
     hrank |-> 1,
     srank |-> 2 ] >>
/\ res = ( v1 :>
      [ chain |-> <<0, 1>>,
        onChain |-> {0, 1},
        head |-> 1,
        state |->
            [nodes |-> {}, admins |-> {k1, k2, k3}, quorum |-> 1, epoch |-> 1],
        alarm |-> FALSE,
        unrevoked |-> {2} ] @@
  v2 :>
      [ chain |-> <<0>>,
        onChain |-> {0},
        head |-> 0,
        state |->
            [ nodes |-> {n1},
              admins |-> {k1, k2, k3},
              quorum |-> 1,
              epoch |-> 0 ],
        alarm |-> FALSE,
        unrevoked |-> {} ] )
/\ anchor = (v1 :> 0 @@ v2 :> 0)
/\ owed = <<>>

